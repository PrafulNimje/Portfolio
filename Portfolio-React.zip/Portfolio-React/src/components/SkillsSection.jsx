export default function SkillsSection() {
  const categories = [
    {
      title: 'Languages',
      icon: 'M12 2L2 7l10 5 10-5-10-5zm0 9l-8.5-4.5L12 2.5l8.5 4L12 11z',
      skills: [
        { name: 'C#', level: 94 },
        { name: 'TypeScript', level: 90 },
        { name: 'JavaScript', level: 86 },
        { name: 'SQL', level: 92 },
        { name: 'HTML5 / CSS3', level: 88 },
      ],
    },
    {
      title: 'Frameworks',
      icon: 'M4 3h16v2H4V3zm0 4h16v2H4V7zm0 4h16v2H4v-2zm0 4h16v2H4v-2z',
      skills: [
        { name: 'ASP.NET Core Web API', level: 92 },
        { name: 'ASP.NET Core MVC', level: 90 },
        { name: 'Angular 16+', level: 86 },
        { name: 'Entity Framework Core', level: 88 },
        { name: 'ADO.NET / LINQ', level: 85 },
        { name: 'Bootstrap', level: 83 },
        { name: 'PrimeNG', level: 80 },
      ],
    },
    {
      title: 'Cloud & DevOps',
      icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.78l4.78 4.78v3.93zm2-1.73l-4.77-4.77c.16-.46.26-.94.26-1.43 0-2.5-2-4.5-4.5-4.5-.5 0-.98.1-1.41.26L7.44 12l4.22 4.22.34-.35v-3.67z',
      skills: [
        { name: 'Azure DevOps (CI/CD)', level: 82 },
        { name: 'GitHub Actions', level: 85 },
        { name: 'Git', level: 90 },
      ],
    },
    {
      title: 'Databases',
      icon: 'M4 4c0 1.66 1.34 3 3 3h10c1.66 0 3-1.34 3-3s-1.34-3-3-3H7c-1.66 0-3 1.34-3 3zm0 5c0 1.66 1.34 3 3 3h10c1.66 0 3-1.34 3-3s-1.34-3-3-3H7c-1.66 0-3 1.34-3 3zm0 5c0 1.66 1.34 3 3 3h10c1.66 0 3-1.34 3-3s-1.34-3-3-3H7c-1.66 0-3 1.34-3 3z',
      skills: [
        { name: 'SQL Server', level: 91 },
        { name: 'Azure SQL', level: 78 },
        { name: 'Stored Procedures', level: 89 },
        { name: 'Query Optimization', level: 87 },
      ],
    },
    {
      title: 'Architecture',
      icon: 'M4 6h16v2H4V6zm0 4h16v2H4v-2zm0 4h16v2H4v-2z',
      skills: [
        { name: 'Microservices', level: 78 },
        { name: 'REST API Design', level: 90 },
        { name: 'N-Tier Architecture', level: 88 },
        { name: 'OOP / Design Patterns', level: 87 },
        { name: 'Repository / Dependency Injection', level: 86 },
        { name: 'SOA', level: 80 },
      ],
    },
    {
      title: 'Testing',
      icon: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
      skills: [
        { name: 'NUnit', level: 82 },
        { name: 'Unit Testing', level: 85 },
        { name: 'Integration Testing', level: 80 },
        { name: 'Debugging', level: 90 },
        { name: 'Performance Tuning', level: 87 },
      ],
    },
    {
      title: 'Reporting & Tools',
      icon: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14H6v-2h6v2zm4 0h-2v-2h2v2zm2 0h-2v-2h2v2z',
      skills: [
        { name: 'RDLC Reports', level: 88 },
        { name: 'Power BI', level: 78 },
        { name: 'SSMS / Postman', level: 85 },
        { name: 'GitHub / Visual Studio', level: 90 },
        { name: 'JIRA', level: 80 },
        { name: 'Claude Code', level: 85 },
      ],
    },
    {
      title: 'Methodologies',
      icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
      skills: [
        { name: 'Agile / Scrum', level: 87 },
        { name: 'SDLC', level: 85 },
        { name: 'Code Reviews', level: 90 },
        { name: 'Technical Documentation', level: 86 },
      ],
    },
  ];

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem' }}>
        {categories.map(cat => (
          <div key={cat.title} style={{ background: 'var(--card-bg)', border: '1px solid var(--border)', borderRadius: '16px', padding: '1.5rem', transition: 'all 0.3s ease' }}>
            <div style={{ marginBottom: '1.25rem' }}>
              <h4 style={{ fontSize: '1.05rem', fontWeight: '700', color: 'var(--text)', letterSpacing: '0.3px' }}>{cat.title}</h4>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
              {cat.skills.map(s => (
                <div key={s.name} style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '20px', padding: '0.35rem 0.85rem', fontSize: '0.85rem', fontWeight: '600', color: 'var(--text)' }}>
                  <span>{s.name}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
