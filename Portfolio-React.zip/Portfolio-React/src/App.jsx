import { useState } from 'react';
import './App.css';
import ThemeToggle from './components/ThemeToggle';
import ScrollIndicators from './components/ScrollIndicators';
import SocialLinks from './components/SocialLinks';
import ParticleBackground from './components/ParticleBackground';
import ProjectsShowcase from './components/ProjectsShowcase';
import SkillsSection from './components/SkillsSection';

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const skills = [
    { category: 'Languages', name: 'C# / TypeScript', level: 92 },
    { category: 'Backend', name: 'ASP.NET Core', level: 90 },
    { category: 'Backend', name: 'Entity Framework Core', level: 88 },
    { category: 'Frontend', name: 'Angular 16+', level: 85 },
    { category: 'Frontend', name: 'React / JavaScript', level: 80 },
    { category: 'Database', name: 'SQL Server', level: 90 },
    { category: 'Cloud', name: 'Azure / Docker', level: 75 },
    { category: 'Tools', name: 'Git / CI/CD', level: 85 },
  ];

  const WaveHeading = ({ text, className = '' }) => (
    <h2 className={`wave-heading ${className}`}>
      {text.split('').map((char, i) => (
        <span key={i} style={{ '--i': i }}>{char}</span>
      ))}
    </h2>
  );

  return (
    <div className="app">
      <ParticleBackground />
      {/* Navigation */}
      <nav className="navbar">
        <div className="nav-container">
          <a href="#" className="nav-logo">Prafull<span>.</span></a>
          <button className="mobile-menu-btn" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
            <span></span><span></span><span></span>
          </button>
          <ul className={`nav-links ${mobileOpen ? 'open' : ''}`}>
            <li><a href="#about">About</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#experience">Experience</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
      </nav>

      <ThemeToggle />
      <ScrollIndicators />

      {/* Hero */}
      <section className="hero" id="top">
        <div className="hero-content">
          <h1 className="wave-heading">Hi, I'm Prafull Nimje — .NET Developer<span style={{ '--i': 39 }}>.</span></h1>
          <p className="hero-subtitle">
            Results-driven .NET Developer with 1+ year of experience delivering production systems for 5,000+ users. Skilled in C#, ASP.NET Core, Angular, SQL Server, Azure, and CI/CD.
          </p>
          <div className="cta-buttons">
            <a href="#skills" className="cta-btn primary">Explore Skills</a>
            <a href="#contact" className="cta-btn secondary">Get in Touch</a>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about">
        <div className="section-title">
          <WaveHeading text="About Me" />
          <p>Passionate developer with sharp focus on building production-ready applications</p>
        </div>
        <div className="about-card">
          <div className="about-card-inner">
            <p><strong>.NET Developer</strong> with 1+ year of hands-on professional experience at RTMSSU, Pune. Specialized in backend architecture using <strong>ASP.NET Core</strong>, <strong>Entity Framework Core</strong>, and <strong>SQL Server</strong> — delivered production systems for 5,000+ users.</p>
            <p>Full-stack expertise with <strong>Angular 16+</strong>, <strong>NgRx</strong>, <strong>Azure DevOps</strong>, <strong>Docker</strong>, and modern CI/CD pipelines. Skilled in requirements gathering, code reviews, technical documentation, and communicating solutions to stakeholders.</p>
          </div>
          <div className="stats">
            {[
              { num: '1+', label: 'Year Experience' },
              { num: '5000+', label: 'Users Served' },
              { num: '10+', label: 'Projects' },
            ].map(s => (
              <div key={s.label} className="stat-box">
                <span className="stat-num">{s.num}</span>
                <span className="stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills */}
      <section id="skills">
        <div className="section-title">
          <WaveHeading text="Technical  Skills" />
          <p>My current technology stack and expertise</p>
        </div>
        <SkillsSection />
      </section>

      {/* Projects */}
      <section id="projects">
        <div className="section-title">
          <WaveHeading text="Projects" />
          <p>Featured work and side projects</p>
        </div>
        <ProjectsShowcase />
      </section>

      {/* Experience */}
      <section id="experience">
        <div className="section-title">
          <WaveHeading text="Experience" />
          <p>Career journey and professional growth</p>
        </div>
        <div className="timeline">
          {[
            { year: 'June 2025 – May 2026', title: '.NET Developer', company: 'Ratan Tata Maharashtra State Skills University (RTMSSU), Pune', desc: 'Engineered end-to-end backend architecture serving 5,000+ students using C#, ASP.NET Core MVC, ADO.NET, and SQL Server. Transformed business requirements from stakeholders into production-grade modules spanning admissions workflows, grievance management, and institutional reporting. Built automated RDLC reporting pipelines for certificates, receipts, and migration documents—eliminating 35% of manual overhead for 500+ users. Architected multi-role approval systems: 200+ admission subsystem and 150+ grievance tracking workflow. Fine-tuned SQL procedures and API endpoints, achieving 20% performance gains. Documented technical specs, data schemas, and training materials for 300+ end users; led UAT cycles and managed phased rollout across all system components. Actively enforce SOLID principles and code quality standards through peer reviews in agile sprints.', tag: 'Current' },
          ].map((item, i) => (
            <div key={item.title} className="timeline-item">
              <div className="timeline-card">
                <div className="timeline-head">
                  <span className="timeline-year">{item.year}</span>
                  <span className="timeline-tag">{item.tag}</span>
                </div>
                <h3 className="timeline-title">{item.title}</h3>
                <p className="timeline-company">{item.company}</p>
                <p className="timeline-desc">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact">
        <div className="section-title">
          <WaveHeading text="Contact" />
          <p>Let's build something together</p>
        </div>
        <div className="contact-card">
          <p style={{fontSize: '1.25rem', marginBottom: '1rem', color: 'var(--text)'}}>Prafull Nimje</p>
          <p style={{fontSize: '1rem', marginBottom: '0.5rem', color: 'var(--accent)'}}>Pune, IN</p>
          <p style={{fontSize: '1rem', marginBottom: '0.5rem', color: 'var(--accent)'}}>+919021070022</p>
          <p style={{fontSize: '1.1rem', marginBottom: '1.5rem', color: 'var(--accent)'}}>prafulnimje1999@gmail.com</p>
          <SocialLinks centered />
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="footer-inner">
          <div className="nav-logo" style={{justifyContent: 'center', fontSize: '2.5rem', marginBottom: '1rem'}}>Prafull<span>.</span></div>
          <p style={{fontSize: '0.9rem', color: 'var(--accent)', marginBottom: '1.5rem'}}>Results-driven .NET Developer — Pune, IN</p>
          <div className="contact-links" style={{marginBottom: '2rem', justifyContent: 'center'}}>
            <a href="#about">About</a>
            <a href="#skills">Skills</a>
            <a href="#projects">Projects</a>
            <a href="#experience">Experience</a>
            <a href="#contact">Contact</a>
          </div>
          <p style={{fontSize: '0.85rem', color: 'var(--accent)'}}>© 2026 Prafull Nimje — Built with React + Vite</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
