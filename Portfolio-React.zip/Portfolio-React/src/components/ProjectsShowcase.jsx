import { useState } from 'react';

export default function ProjectsShowcase() {
  const [selectedProject, setSelectedProject] = useState(null);

  const projects = [
    {
      title: 'Clinical Task Manager',
      shortDesc: 'Full-stack clinical task management platform with Admin/Staff roles.',
      fullDescription: 'A comprehensive healthcare task management system enabling clinical staff to assign, track, and complete patient-related tasks efficiently. Features role-based access control for administrators and staff members, real-time task updates, and comprehensive reporting capabilities.',
      features: [
        'Role-based authentication (Admin/Staff) with JWT tokens',
        'Angular 16+ with NgRx for state management',
        'PrimeNG UI components for modern interface',
        'ASP.NET Core Web API with Entity Framework Core',
        'Docker containerization and Azure App Service deployment',
        'GitHub Actions CI/CD pipeline automation',
        'NUnit unit and integration test coverage',
      ],
      tags: ['Angular 16+', 'NgRx', 'ASP.NET Core', 'Docker', 'Azure'],
      link: '#'
    },
    {
      title: 'Short Term Course Management Portal',
      shortDesc: 'Multi-role batch and student management portal serving 100+ users.',
      fullDescription: 'A comprehensive portal for managing short-term courses, student enrollments, attendance tracking, and certificate generation. Enables administrators to create courses, enroll students, track attendance with geotagged photos, and generate completion certificates automatically.',
      features: [
        'Course creation and batch management',
        'Student enrollment system',
        'Geotagged photo-based attendance tracking (500+ verified sessions)',
        'Automated certificate generation with eligibility validation',
        'Optimized SQL stored procedures for fast data retrieval',
        'Responsive Bootstrap admin panel',
        'Marks management for 200+ students',
      ],
      tags: ['C#', 'ASP.NET', 'SQL Server', 'ADO.NET', 'Bootstrap'],
      link: '#'
    },
    {
      title: 'RTMSSU Management Portal',
      shortDesc: 'Multi-module student management platform for 300+ end-users.',
      fullDescription: 'A comprehensive university management system developed for Ratan Tata Maharashtra State Skills University. Handles admissions, grievances, and certificate generation for thousands of students with role-based access control.',
      features: [
        'Multi-role admission approval subsystem (200+ students)',
        'Grievance workflow management (150+ requests)',
        'Automated RDLC report pipelines (certificates, receipts, migration documents)',
        'Certificate document generation (500+ documents)',
        '35% reduction in manual reporting overhead',
        '20% SQL query performance improvement',
        'Technical documentation and UAT support',
      ],
      tags: ['ASP.NET Core MVC', 'SQL Server', 'RDLC', 'ADO.NET'],
      link: '#'
    },
  ];

  return (
    <>
      <div className="projects-grid">
        {projects.map((project) => (
          <div key={project.title} className="project-card">
            <div className="project-content">
              <div className="project-tags">
                {project.tags.map(tag => (
                  <span key={tag} className="project-tag">{tag}</span>
                ))}
              </div>
              <h3 className="project-title">{project.title}</h3>
              <p className="project-desc">{project.shortDesc}</p>
              <div className="project-links">
                <button
                  className="project-link"
                  onClick={() => setSelectedProject(project)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                >
                  View Project
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <div className="project-modal-overlay" onClick={() => setSelectedProject(null)}>
          <div className="project-modal" onClick={e => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedProject(null)}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>

            <div className="modal-header">
              <div className="modal-tags">
                {selectedProject.tags.map(tag => (
                  <span key={tag} className="modal-tag">{tag}</span>
                ))}
              </div>
              <h2 className="modal-title">{selectedProject.title}</h2>
              <p className="modal-desc">{selectedProject.fullDescription}</p>
            </div>

            <div className="modal-body">
              <h3 className="modal-section-title">Key Features</h3>
              <ul className="modal-features">
                {selectedProject.features.map((feature, i) => (
                  <li key={i}>{feature}</li>
                ))}
              </ul>
            </div>

            <div className="modal-footer">
              <a href={selectedProject.link} className="modal-cta" target="_blank" rel="noopener noreferrer">
                View Live Project
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
}