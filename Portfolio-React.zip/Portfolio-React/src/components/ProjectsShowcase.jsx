export default function ProjectsShowcase() {
  const projects = [
    {
      title: 'Clinical Task Manager',
      description: 'Full-stack clinical task management platform with Admin/Staff roles. Built reactive UI with Angular 16+, NgRx state management, PrimeNG components, and JWT-protected routes. Engineered ASP.NET Core Web API with role-based authorization, EF Core migrations, and comprehensive NUnit test coverage. Containerized with Docker, deployed to Azure App Service via GitHub Actions CI/CD pipeline.',
      tags: ['Angular 16+', 'NgRx', 'ASP.NET Core', 'Docker', 'Azure'],
      link: '#'
    },
    {
      title: 'Short Term Course Management Portal',
      description: 'Multi-role batch and student management portal serving 100+ users. Implemented course creation, student enrollment, and geotagged photo-based attendance tracking with 500+ verified session records. Built automated certificate generation with eligibility validation logic for 200+ students. Optimized SQL stored procedures for faster batch data retrieval and built responsive Bootstrap admin panel.',
      tags: ['C#', 'ASP.NET', 'SQL Server', 'ADO.NET', 'Bootstrap'],
      link: '#'
    },
    {
      title: 'RTMSSU Management Portal',
      description: 'Multi-module student management platform for 300+ end-users covering admissions (200+ students), grievance routing (150+ requests), and certificate document generation (500+ documents). Automated 5+ RDLC report pipelines eliminating 35% manual processing overhead. Optimized SQL procedures achieving 20% performance gain. Delivered full technical documentation and conducted UAT walkthroughs.',
      tags: ['ASP.NET Core MVC', 'SQL Server', 'RDLC', 'ADO.NET'],
      link: '#'
    },
  ];

  return (
    <div className="projects-grid">
      {projects.map((project) => (
        <div key={project.title} className="project-card">
          <div className="project-content">
            <div className="project-tags">
              {project.tags.map(tag => (
                <span key={tag} className="project-tag">{tag}</span>
              ))}
            </div>
            <h3 className="project-title">{project.title}</h3>
            <p className="project-desc">{project.description}</p>
            <div className="project-links">
              <a href={project.link} className="project-link" target="_blank" rel="noopener noreferrer">
                View Project
              </a>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
